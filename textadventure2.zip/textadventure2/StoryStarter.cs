﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using textadventur;

namespace textadventure2
{
    internal class StoryStarter
    {
       public void Start()
        {
        room rooms = new room();
        RoomDesign roomdesign = new RoomDesign();
        information information = new information();

        Console.WriteLine("please only use english in this adventure");
            Console.WriteLine("press any key to start");
            Console.ReadKey();
            information.backstory();
            rooms.Rooms();

        }
    }
}
