﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace textadventure2
{
    internal class Games
    { 
            int time = 0;
        string input;
        int tile;        
       public void game1()
        {
            Console.WriteLine("so you enter the room and the door closes behind you there is no way back");
            Console.WriteLine("you go forward and you see on a screen welcome to golden bridge");
            Console.WriteLine("to get to the other side and recieve the prize you have to jump on the platforms");
            Console.WriteLine("but be carefull if you jump on a damaged platform you fall and die");
            Console.WriteLine("give a number from 1 thru 3");
            Console.WriteLine("the last twoo are only two options");
            Console.WriteLine("1/5");
            input = Console.ReadLine();
            tile = Convert.ToInt32(input);
            switch (tile)
            {
                case 1:
                    
                    Console.WriteLine("save platform");
                    break;
                case 2:
                    Console.WriteLine("not save platform");
                    Environment.Exit(0);
                    break;
                case 3:
                    Console.WriteLine("save platform");
                    break;
            }
            Console.WriteLine("2/5");
            input = Console.ReadLine();
            tile = Convert.ToInt32(input);
            switch (tile)
            {
                case 1:
                    Console.WriteLine("not save");
                    Environment.Exit(0);
                    break; 
                case 2:
                    Console.WriteLine("save");
                    break;
                case 3:
                    Console.WriteLine("save");
                    break;
            }
            Console.WriteLine("3/5");
            input = Console.ReadLine();
            tile = Convert.ToInt32(input);
            switch (tile)
            {
                case 1:
                    Console.WriteLine("save");
                    break;
                case 2:
                    Console.WriteLine("save");
                    break;
                case 3:
                    Console.WriteLine("not save");
                    Environment.Exit(0);
                    break;
            }
            Console.WriteLine("4/5");
           input = Console.ReadLine();
            tile = Convert.ToInt32(input);
            switch (tile)
            {
                case 1:
                    Console.WriteLine("save");
                    break;
                case 2:
                    Console.WriteLine("not save");
                    Environment.Exit(0);
                    break;
            }
            Console.WriteLine("5/5");
            input = Console.ReadLine();
            tile = Convert.ToInt32(input);
            switch (tile)
            {
                case 1:
                    Console.WriteLine("not save");
                    Environment.Exit(0);
                    break;
                case 2:
                    Console.WriteLine("save");
                    break;
            }
            Console.WriteLine("you have made it take this reward a golden note " +
                "with" +
                "" +
                "vis on it");
       }
        public void game2()
        {
            Console.WriteLine("welcome to the reaction game");
            Console.WriteLine("you have to type the word that is shown before the time runs out");
            Console.WriteLine("you get 5 seconds every time");
            Console.WriteLine("press a key to continue");
            Console.ReadKey();
            Console.WriteLine("youre first word is rock");
            Console.WriteLine("1/6");
            record_time();
            string input = Console.ReadLine();
            Console.WriteLine($"you took {time} seconds to write {input}");
            if (time > 5)
            {
                Console.WriteLine("you got smushed by a boudler cause you took to long");
                Environment.Exit(0);
            }
            time = 0;
            Console.WriteLine("word two is bush");
            Console.WriteLine("2/6");
            record_time() ;
            input = Console.ReadLine();    
            Console.WriteLine($"you took {time} to write {input}");
            if (time > 5)
            {
                Console.WriteLine("you got smushed by a boudler cause you took to long");
                Environment.Exit(0);
            }
            time = 0;
            Console.WriteLine("word three is trucker");
            Console.WriteLine("3/6");
            record_time();
            input = Console.ReadLine();
            Console.WriteLine($"you took {time} to write {input}");
            if (time > 5)
            {
                Console.WriteLine("you got smushed by a boudler cause you took to long");
                Environment.Exit(0);
            }
            Console.WriteLine("your fourth word is truckdriver");
            Console.WriteLine("4/6");
            record_time();
            input = Console.ReadLine();
            Console.WriteLine($"you took {time} to write {input}");
            if (time > 5)
            {
                Console.WriteLine("you got smushed by a boudler cause you took to long");
                Environment.Exit(0);
            }
            time = 0;
            Console.WriteLine("your fifth word is Photosynthesis");
            Console.WriteLine("5/6");
            record_time();
            input = Console.ReadLine();
            Console.WriteLine($"you took {time} to write {input}");
            if (time > 5)
            {
                Console.WriteLine("you got smushed by a boudler cause you took to long");
                Environment.Exit(0);
            }
            time = 0;
            Console.WriteLine("your sixth word is Antidisestablishmentarianism");
            Console.WriteLine("for this word you get 10 seconds");
            Console.WriteLine("6/6");
            record_time();
            input = Console.ReadLine();
            Console.WriteLine($"you took {time} to write {input}");
            if (time > 10)
            {
                Console.WriteLine("you got smushed by a boudler cause you took to long");
                Environment.Exit(0);
            }
            Console.WriteLine("you have completed it have this as a reward");
            Console.WriteLine("a golden not with cha on it");





        }
        void record_time()
        {
            while (!Console.KeyAvailable)
            {
                Thread.Sleep(1000);
                time++;

            }
        }
    }
}
