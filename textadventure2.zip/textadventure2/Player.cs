﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textadventur
{
    internal class Player
    {
       int playerHp;
        int playerAttack;
        
    
        public int playerAttackdamage()
        {
            playerAttack = 15;

            return playerAttack;
        }
        public int takedamage(int damage)
        {
            playerHp = 30;
            playerHp  -= damage;
            return playerHp;
        }
        public int playerhealth()
        {
            return playerHp;
        }

    }
}
