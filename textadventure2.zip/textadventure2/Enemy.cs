﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textadventur
{
    internal class enemy
    {
        Random rd = new Random();
        int enemyHP = 100;
        int enemyAttack;
      
        public int EnemyAttackDamage()
        {
            enemyAttack = 10;
            return enemyAttack;
        }
        public int EnemyChoice()
        {
            int choice = rd.Next(1,3);
            switch(choice)
            {
                case 1:
                    Console.WriteLine("attack");
                    break;
                case 2:
                    Console.WriteLine("defend");
                    break;
            }
            return choice;
        }
        public int takedamage(int damage)
        {
            enemyHP -= damage;
            return enemyHP;
        }
        public int enemyhealth()
        {
            return enemyHP;
        }
    }
}
