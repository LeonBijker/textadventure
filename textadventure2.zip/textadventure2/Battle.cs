﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textadventur
{
    internal class battle
    {
        string input;
        Player Player = new Player();
        enemy enemy = new enemy();
        bool loop = true;
        public int choice;
        int playerdamage = 15;
        int enemydamage = 10;

        public void TooBatlle()
        {
            while (loop)
            {
                Console.WriteLine("player HP " + Player.playerhealth());
                Console.WriteLine("player AttackDamage " + Player.playerAttackdamage());
                Console.WriteLine("enemy HP" + enemy.enemyhealth());
                Console.WriteLine("enemy AttackDamage " + enemy.EnemyAttackDamage());
                Battleoptions();
                if (Player.playerhealth() < 0 || enemy.enemyhealth() < 0)
                {
                    if (Player.playerhealth() < 1)
                    {
                        Console.WriteLine("enemy won");
                        Console.WriteLine("youre dead");
                        Console.ReadKey();
                        Environment.Exit(0);
                    }
                    else if (enemy.enemyhealth() < 1)
                    {
                        Console.WriteLine("you won continue");
                        Console.ReadKey();
                    }

                    loop = false;
                }
            }

        }
        void enemychoice()
        {
            choice = enemy.EnemyChoice();

        }
        void Battleoptions()
        {

            Console.WriteLine("player choose what to do");
            input = Console.ReadLine();
            Console.WriteLine("enemy choice =");
            enemychoice();
            if (input == "attack" && choice != 2)
            {
                enemy.takedamage(playerdamage);
            }
            else if (input == "defend")
            {
                enemy.takedamage(0);
            }
            if (choice == 1 && input != "defend")
            {
                Console.WriteLine("attack");
                Player.takedamage(enemydamage);
            }
            else if (choice == 2)
            {
                Console.WriteLine("defend");
                Player.takedamage(0);
            }


        }
    }
}
