﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace textadventur
{
    internal class room
    {
        Random rd = new Random();
        battle toobattle = new battle();
        RoomDesign roomsdesign = new RoomDesign();
        information information = new information();


        string patch = "ascii-art_viscachaV3.txt";

        public int rooms;
        public int deathcount;
        public string input;
        public int roomcounter = 0;
        bool loop = true;
        bool keypress;
        public int Rooms()
        {
            while (loop)
            {


                Console.Clear();

                rooms = rd.Next(1, 13);
                switch (rooms)
                {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        Console.WriteLine("you are in room " + roomcounter);
                        Console.WriteLine($"and you have{deathcount}deaths");
                       // string[] counters = { $"amount of deaths{deathcount}", $"amount of room you have entered{roomcounter}" };
                        roomsdesign.design();
                        roomcounter++;
                        break;
                    case 11:
                        if (roomcounter >= 5)
                        {

                            Console.WriteLine("Wow, you have found a secret room!");
                            Console.WriteLine("but do you have a key");
                            switch (roomsdesign.key)
                            {
                                case 0:
                                    Console.WriteLine("you dont have a key continue to search to find a key");
                                    break;
                                case 1:
                                    extrainfo();
                                    Console.WriteLine("you have found the secret viscacha and left the building");
                                    information.endstory();
                                    Console.WriteLine("press a key to end the adventure");
                                    Console.WriteLine("cause you have finished the adventure");
                                    Console.ReadKey();
                                    Environment.Exit(0);
                                    break;
                            }

                        }
                        else
                        {
                            Console.WriteLine("you are in room " + roomcounter);
                            roomcounter++;
                            break;
                        }
                        break;

                    case 12:
                        if (roomcounter >= 10)
                        {
                            Console.WriteLine("you have found a secret room but");
                            toobattle.TooBatlle();
                            break;
                        }
                        else
                        {
                            Console.WriteLine("you are in room " + roomcounter);
                            break;
                        }


                    default:
                        Console.WriteLine("How did you get here?");
                        break;

                }
            }
            return rooms;


        }
        public string extrainfo()
        {
            string[] lines = File.ReadAllLines(patch);

            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }
            Console.ReadLine();
            return "Viscacha";

        }

    }
}
