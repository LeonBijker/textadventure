﻿using textadventure2;

namespace textadventur
{
    internal class Program
    {
        static void Main(string[] args)
        {

            StoryStarter st = new StoryStarter();
            st.Start();
        }

    }
}
